function varargout = planner002(varargin)
% PLANNER002 MATLAB code for planner002.fig
%
%     PLANNER002 Is a flight path planner designed to help plan missions
%
%      for CReSIS. When run, Planner002 will display a GUI and allow user
%
%      input of mission details. It will output a graph of the mission
%
%      flight plan, a text file of GPS waypoints, and some relevant warnings
%
%      and suggestions regarding mission planning.
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help planner002

% Last Modified by GUIDE v2.5 31-Jan-2017 08:43:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @planner002_OpeningFcn, ...
                   'gui_OutputFcn',  @planner002_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before planner002 is made visible.
function planner002_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = planner002_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;


% --- Executes on button press in PlotButton.
function PlotButton_Callback(hObject, eventdata, handles)

%Alrighty, the variables you have so far are: (handles. in front of
%everything)


%SciTarLat, SciTarLong, CustTLat, CustTLong, NumLines, LineHeading,
%LineLength, LineSpace, CustRange, CustCruise, SpeedConversion,
%RangeConversion, CustAPLat, CustAPLong, APLat, APLong


%If a radio button hasn't been selected in every field, the next line makes
%sure the plot button does nothing
%if (isfield(handles,'SciTarLat') == 1) && (isfield(handles,'SciTarLong') == 1) && (isfield(handles,'NumLines') == 1) && (isfield(handles,'LineHeading') == 1) && (isfield(handles,'LineLength') == 1) && (isfield(handles,'LineSpace') == 1) && (isfield(handles,'SpeedConversion') == 1)
   %This function checks for custom inputs, and assigns appropriate values
   %to variables
   %CustomInput(hObject, handles)
   %The next line checks that the CustomInput function completed
   %successfully.
   %if isfield(handles, 'fail') == 0
        %All actual program code goes here
       
       %Need to generate flight line coordinates
       

       [lats, longs] = GenFlightLines(handles)
       [XCords, YCords] = CartConv(lats,longs);
       figure(2)
       plot(XCords,YCords)
       
       
        
       
       
   %end
%else
    %disp('You need to make a selection for every field')
    
%end

function[x,y] = CartConv(lats,longs)
R = 6371000;
x = R.*cos(lats).*cos(longs);
y = R.*cos(lats).*sin(longs);


function[lats, longs] = GenFlightLines(handles)
Bearing = handles.LineHeading;
length = handles.LineLength
R = 6371000;
space = handles.LineSpace;

lats(1) = handles.SciTarLat;
longs(1) = handles.SciTarLong;
[lats(2), longs(2)] = NewPoint(lats(1), longs(1), Bearing, length);

for i= 2:handles.NumLines
    if mod(i, 2) == 0
        [lats(2*i-1), longs(2*i-1)] = NewPoint(lats(2*i-2), longs(2*i-2), Bearing+90, space);
        [lats(2*i), longs(2*i)] = NewPoint(lats(2*i-1), longs(2*i-1), Bearing+180, length);
    else
        [lats(2*i-1), longs(2*i-1)] = NewPoint(lats(2*i-2), longs(2*i-2), Bearing+90, space);
        [lats(2*i), longs(2*i)] = NewPoint(lats(2*i-1), longs(2*i-1), Bearing, length);
    end
end





function [newlat, newlong] = NewPoint(lat, long, bearing, d)
R = 6371000;
newlat = asind(sind(lat)*cos(d/R)+cosd(lat)*sin(d/R)*cosd(bearing));
A = sind(bearing)*sin(d/R)*cosd(lat);
B = cos(d/R) - sind(lat)*sind(newlat);
newlong = long + atan2d(A,B);

function [d] = FlightDistance(Lat1, Long1, Lat2, Long2)

    d= 2*6371000*asin(sqrt(sind((Lat2-Lat1)/2)^2 + cosd(Lat1)*cosd(Lat2)*sind((Long2-Long1)/2)^2));
    
function CustomInput(hObject, handles)
if (handles.SciTarLat == -100) && (isfield(handles,'CustTLat') == 1) && (isfield(handles,'CustTLong') == 1)
    handles.SciTarLat = handles.CustTLat;
    handles.SciTarLong = handles.CustTLong;
else
    display('You need to fill out every custom field when you select a custom option')
    handles.fail = 1;
    disp('failed for scitar')
end
if (handles.APLat == -100) && (isfield(handles,'CustAPLat') == 1) && (isfield(handles,'CustAPLong') == 1)
    handles.APLat = handles.CustAPLat;
    handles.APLong = handles.CustAPLong;
    
else
    display('You need to fill out every custom field when you select a custom option')
    handles.fail = 1;
    disp('failed for aplat')
end
if (handles.Cruise == -100) && (isfield(handles,'CustCruise') == 1) && (isfield(handles,'CustRange') == 1)
    handles.Cruise = handles.CustCruise;
    handles.Range = handles.CustRange;
else
    display('You need to fill out every custom field when you select a custom option')
    handles.fail = 1;
    disp('failed for range')
end

guidata(hObject, handles);

function FlightLines_Callback(hObject, eventdata, handles)


handles.NumLines = str2double(get(hObject,'String'));
guidata(hObject, handles);

function FlightLines_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FlightLines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LineLength_Callback(hObject, eventdata, handles)


handles.LineLength = str2double(get(hObject,'String'));
guidata(hObject, handles);

function LineLength_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LineSpacing_Callback(hObject, eventdata, handles)


handles.LineSpace = str2double(get(hObject,'String'));
guidata(hObject, handles);

function LineSpacing_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LineHeading_Callback(hObject, eventdata, handles)
% hObject    handle to LineHeading (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LineHeading as text
%        str2double(get(hObject,'String')) returns contents of LineHeading as a double

% --- Executes during object creation, after setting all properties.


handles.LineHeading = str2double(get(hObject,'String'));
guidata(hObject, handles);

function LineHeading_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LineHeading (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CustTLat_Callback(hObject, eventdata, handles)
% hObject    handle to CustTLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustTLat as text
%        str2double(get(hObject,'String')) returns contents of CustTLat as a double

handles.CustTLat = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustTLat_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CustTLong_Callback(hObject, eventdata, handles)
% hObject    handle to CustTLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustTLong as text
%        str2double(get(hObject,'String')) returns contents of CustTLong as a double
handles.CustTLongEntered = 1;
handles.CustTLong = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustTLong_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CustRange_Callback(hObject, eventdata, handles)
% hObject    handle to CustRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustRange as text
%        str2double(get(hObject,'String')) returns contents of CustRange as a double
handles.CustRangeEntered = 1;
handles.CustRange = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustRange_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CustCruise_Callback(hObject, eventdata, handles)
% hObject    handle to CustCruise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustCruise as text
%        str2double(get(hObject,'String')) returns contents of CustCruise as a double
handles.CustCruiseEntered = 1;
handles.CustCruise = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustCruise_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function bgPlanes_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bgPlanes 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)


switch get(eventdata.NewValue,'Tag')
    case 'rbSierra'
        handles.Cruise = 30.8667; %m/s
        handles.Range = 1018600; %m
    case 'rbP3'
        handles.Cruise = 169.767; %m/s
        handles.Range = 5556000; %m
    case 'rbTwinOtter'
        handles.Cruise = 56.5889; %m/s
        handles.Range = 1574200; %m
    case 'rbCustomPlane'
        handles.Cruise = -100;
        handles.Range = -100;
end

guidata(hObject, handles);

function bgScienceTargets_SelectionChangeFcn(hObject, eventdata, handles)

%SciTarLat
%SciTarLong

switch get(eventdata.NewValue,'Tag')
    case 'rbChamb'
        handles.SciTarLat = 76.743607;%
        handles.SciTarLong = -68.615041;%
    case 'rbCampC'
        handles.SciTarLat = 77.166696;%
        handles.SciTarLong = -61.133369;%
    case 'rbJakob'
        handles.SciTarLat = 69.215840;%
        handles.SciTarLong = -49.798696;%
    case 'rbRusse'
        handles.SciTarLat = 67.101912;%
        handles.SciTarLong = -50.225496;%
    case 'rbColumbiaG'
        handles.SciTarLat = 61.170380;%
        handles.SciTarLong = -147.026099;%
    case 'rbNuukG'
        handles.SciTarLat = 65.212518;%
        handles.SciTarLong = -50.662002;%
    case 'rbOtherTarget'
        handles.SciTarLat = -100;%
        handles.SciTarLong = -100;%
end
guidata(hObject, handles);

function bgUnits_SelectionChangeFcn(hObject, eventdata, handles)

switch get(eventdata.NewValue,'Tag')
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMiles'
        handles.SpeedConversion = 0.44704;
        handles.RangeConversion = 1609.34;
    case 'rbKnots'
        handles.SpeedConversion = 0.514444;
        handles.RangeConversion = 1852;
    case 'rbKm'
        handles.SpeedConversion = 0.277778;
        handles.RangeConversion = 1000;
end
guidata(hObject, handles);

function bgAirports_SelectionChangeFcn(hObject, eventdata, handles)
%Sets the latitude and longitude of the mission airport
%APLat, APLong

switch get(eventdata.NewValue,'Tag')
    case 'rbThule'
        handles.APLat = 77.46666666666667;%
        handles.APLong = -69.23055555555555;%
    case 'rbIlulissat'
        handles.APLat = 69.21666666666667;%
        handles.APLong = -51.1;%
    case 'rbKang'
        handles.APLat = 67.00861111111111;%
        handles.APLong = -50.689166666666665;%
    case 'rbNuuk'
        handles.APLat = 64.17500000000001;%
        handles.APLong = 51.73888888888889;%
    case 'rbValdez'
        handles.APLat = 61.85;%
        handles.APLong = -146.34833333333333;%
    case 'rbBarrow'
        handles.APLat = 71.29055555555556;%
        handles.APLong = -156.78861111111112;%
    case 'rbCustAP'
        handles.APLat = -100;%
        handles.APLong = -100;%


end
guidata(hObject, handles);

function CustAPLong_Callback(hObject, eventdata, handles)
% hObject    handle to CustAPLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustAPLong as text
%        str2double(get(hObject,'String')) returns contents of CustAPLong as a double

handles.CustAPLong = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustAPLong_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CustAPLat_Callback(hObject, eventdata, handles)
% hObject    handle to CustAPLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustAPLat as text
%        str2double(get(hObject,'String')) returns contents of CustAPLat as a double
handles.CustAPLat = str2double(get(hObject,'String'));
guidata(hObject, handles);

function CustAPLat_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
