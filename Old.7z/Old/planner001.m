function varargout = planner001(varargin)
% PLANNER001 MATLAB code for planner001.fig
%      PLANNER001, by itself, creates a new PLANNER001 or raises the existing
%      singleton*.
%
%      H = PLANNER001 returns the handle to a new PLANNER001 or the handle to
%      the existing singleton*.
%
%      PLANNER001('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PLANNER001.M with the given input arguments.
%
%      PLANNER001('Property','Value',...) creates a new PLANNER001 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before planner001_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to planner001_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help planner001

% Last Modified by GUIDE v2.5 30-Jan-2017 12:39:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @planner001_OpeningFcn, ...
                   'gui_OutputFcn',  @planner001_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before planner001 is made visible.
function planner001_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to planner001 (see VARARGIN)

% Choose default command line output for planner001
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes planner001 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = planner001_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure





varargout{1} = handles.output;


% --- Executes on button press in PlotButton.
function PlotButton_Callback(hObject, eventdata, handles)
% hObject    handle to PlotButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function FlightLines_Callback(hObject, eventdata, handles)
% hObject    handle to FlightLines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FlightLines as text
%        str2double(get(hObject,'String')) returns contents of FlightLines as a double

handles.NumLines = str2double(get(hObject,'String'));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function FlightLines_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FlightLines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function LineLength_Callback(hObject, eventdata, handles)
% hObject    handle to LineLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LineLength as text
%        str2double(get(hObject,'String')) returns contents of LineLength as a double

handles.LineLength = str2double(get(hObject,'String'));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function LineLength_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LineLength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function LineSpacing_Callback(hObject, eventdata, handles)
% hObject    handle to LineSpacing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LineSpacing as text
%        str2double(get(hObject,'String')) returns contents of LineSpacing as a double

handles.LineSpace = str2double(get(hObject,'String'));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function LineSpacing_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LineSpacing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function LineHeading_Callback(hObject, eventdata, handles)
% hObject    handle to LineHeading (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LineHeading as text
%        str2double(get(hObject,'String')) returns contents of LineHeading as a double

% --- Executes during object creation, after setting all properties.

handles.LineHeading = str2double(get(hObject,'String'));
guidata(hObject, handles);


function LineHeading_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LineHeading (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CustTLat_Callback(hObject, eventdata, handles)
% hObject    handle to CustTLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustTLat as text
%        str2double(get(hObject,'String')) returns contents of CustTLat as a double


% --- Executes during object creation, after setting all properties.
function CustTLat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustTLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CustTLong_Callback(hObject, eventdata, handles)
% hObject    handle to CustTLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustTLong as text
%        str2double(get(hObject,'String')) returns contents of CustTLong as a double


% --- Executes during object creation, after setting all properties.
function CustTLong_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustTLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CustRange_Callback(hObject, eventdata, handles)
% hObject    handle to CustRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustRange as text
%        str2double(get(hObject,'String')) returns contents of CustRange as a double


% --- Executes during object creation, after setting all properties.
function CustRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CustCruise_Callback(hObject, eventdata, handles)
% hObject    handle to CustCruise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustCruise as text
%        str2double(get(hObject,'String')) returns contents of CustCruise as a double


% --- Executes during object creation, after setting all properties.
function CustCruise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustCruise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when selected object is changed in bgPlanes.
function bgPlanes_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bgPlanes 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected object is changed in bgScienceTargets.

switch get(eventdata.NewValue,'Tag')
    case 'rbSierra'
        handles.Cruise = 30.8667; %m/s
        handles.Range = 1018600; %m
    case 'rbP3'
        handles.Cruise = 169.767; %m/s
        handles.Range = 5556000; %m
    case 'rbTwinOtter'
        handles.Cruise = 56.5889; %m/s
        handles.Range = 1574200; %m
    case 'rbCustomPlane'
        handles.Cruise = -1;
        handles.Range = -1;
end


function bgScienceTargets_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bgScienceTargets 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)

switch get(eventdata.NewValue,'Tag')
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
end

% --- Executes when selected object is changed in bgUnits.
function bgUnits_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bgUnits 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
switch get(eventdata.NewValue,'Tag')
    case 'rbMeters'
        handles.SpeedConversion = 1;
        handles.RangeConversion = 1;
    case 'rbMiles'
        handles.SpeedConversion = 0.44704;
        handles.RangeConversion = 1609.34;
    case 'rbKnots'
        handles.SpeedConversion = 0.514444;
        handles.RangeConversion = 1852;
    case 'rbKm'
        handles.SpeedConversion = 0.277778;
        handles.RangeConversion = 1000;
end

% --- Executes when selected object is changed in bgAirports.
function bgAirports_SelectionChangeFcn(hObject, eventdata, handles)
%Sets the latitude and longitude of the mission airport
%APLat, APLong

switch get(eventdata.NewValue,'Tag')
    case 'rbThule'
        handles.APLat = 77.46666666666667;%
        handles.APLong = -69.23055555555555;%
    case 'rbIlulissat'
        handles.APLat = 69.21666666666667;%
        handles.APLong = -51.1;%
    case 'rbKang'
        handles.APLat = 67.00861111111111;%
        handles.APLong = -50.689166666666665;%
    case 'rbNuuk'
        handles.APLat = 64.17500000000001;%
        handles.APLong = 51.73888888888889;%
    case 'rbValdez'
        handles.APLat = 61.85;%
        handles.APLong = -146.34833333333333;%
    case 'rbBarrow'
        handles.APLat = 71.29055555555556;%
        handles.APLong = -156.78861111111112;%
    case 'rbCustAP'
        handles.APLat = 1234;%
        handles.APLong = 1234;%


end

function CustAPLong_Callback(hObject, eventdata, handles)
% hObject    handle to CustAPLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustAPLong as text
%        str2double(get(hObject,'String')) returns contents of CustAPLong as a double


% --- Executes during object creation, after setting all properties.
function CustAPLong_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustAPLong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CustAPLat_Callback(hObject, eventdata, handles)
% hObject    handle to CustAPLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CustAPLat as text
%        str2double(get(hObject,'String')) returns contents of CustAPLat as a double


% --- Executes during object creation, after setting all properties.
function CustAPLat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CustAPLat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
